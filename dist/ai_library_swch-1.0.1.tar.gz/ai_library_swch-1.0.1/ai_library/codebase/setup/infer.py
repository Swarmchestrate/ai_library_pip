import pickle
import os

import pandas as pd
import torch
import yaml

# Use package-relative imports to be import-safe when the package is installed.
from ..models.iTransformer_class import iTransformer_pipeline
from ..models.gmlp_class import gMLP_pipeline
from ..models.xgb_class import XGBoost_pipeline
from ..helpers.pivot_df import pivot_df
from ..helpers.config_helper import validate_config
from ..helpers.inference_to_parquet import ingest_to_inference_parquet

def inference():
    config = validate_config()
    saved_files_dir = os.path.expanduser(config.get("saved_files_dir"))
    os.makedirs(saved_files_dir, exist_ok=True)
    pipeline_type = config["pipeline_type"]
    window = config["window"]
    targets = config["prediction_target"]
    cols_to_drop = config.get("cols_to_drop", [])
    resample_frequency = config.get("data_frequency")
    if pipeline_type == "gmlp":
        pipeline = gMLP_pipeline()
        #print("loading gMLP model from", os.path.join(saved_files_dir, "trained_model_gmlp.pth"))
        pipeline.model = torch.load(
            os.path.join(saved_files_dir, "trained_model_gmlp.pth"), 
            map_location="cpu", 
            weights_only=False)
        pipeline.scaler_x = pickle.load(open(os.path.join(saved_files_dir, "scaler_x_gmlp.pkl"), "rb"))
        pipeline.scaler_y = pickle.load(open(os.path.join(saved_files_dir, "scaler_y_gmlp.pkl"), "rb"))
        pipeline.clipping_min = pickle.load(open(os.path.join(saved_files_dir, "clipping_min_gmlp.pkl"), "rb"))
        pipeline.clipping_max = pickle.load(open(os.path.join(saved_files_dir, "clipping_max_gmlp.pkl"), "rb"))
        pipeline.conformal_q = pickle.load(open(os.path.join(saved_files_dir, "conformal_q_gmlp.pkl"), "rb"))
        pipeline.target_names = pickle.load(open(os.path.join(saved_files_dir, "target_names_gmlp.pkl"), "rb"))
    elif pipeline_type == "xgb":
        pipeline = XGBoost_pipeline()
        #print("loading xgboost model from", os.path.join(saved_files_dir, "trained_model_xgb.pkl"))
        pipeline.model = pickle.load(open(os.path.join(saved_files_dir, "trained_model_xgb.pkl"), "rb"))
        pipeline.scaler_x = pickle.load(open(os.path.join(saved_files_dir, "scaler_x_xgb.pkl"), "rb"))
        pipeline.scaler_y = pickle.load(open(os.path.join(saved_files_dir, "scaler_y_xgb.pkl"), "rb"))
        pipeline.clipping_min = pickle.load(open(os.path.join(saved_files_dir, "clipping_min_xgb.pkl"), "rb"))
        pipeline.clipping_max = pickle.load(open(os.path.join(saved_files_dir, "clipping_max_xgb.pkl"), "rb"))
        pipeline.conformal_q = pickle.load(open(os.path.join(saved_files_dir, "conformal_q_xgb.pkl"), "rb"))
        pipeline.target_names = pickle.load(open(os.path.join(saved_files_dir, "target_names_xgb.pkl"), "rb"))
    elif pipeline_type == "itransformer":
        pipeline = iTransformer_pipeline()
        #print("loading iTransformer model from", os.path.join(saved_files_dir, "trained_model_itransformer.pth"))
        pipeline.model = torch.load(
            os.path.join(saved_files_dir, "trained_model_itransformer.pth"), 
            map_location="cpu", 
            weights_only=False)
        pipeline.scaler_x = pickle.load(open(os.path.join(saved_files_dir, "scaler_x_itransformer.pkl"), "rb"))
        pipeline.scaler_y = pickle.load(open(os.path.join(saved_files_dir, "scaler_y_itransformer.pkl"), "rb"))
        pipeline.target_columns = pickle.load(open(os.path.join(saved_files_dir, "target_columns_itransformer.pkl"), "rb"))
        pipeline.n_past = window
        pipeline.n_targets = len(pipeline.target_columns)
        pipeline.time_column = "ts"
        pipeline.pred_len = config.get("horizon")
        pipeline.feature_columns = pickle.load(open(os.path.join(saved_files_dir, "feature_columns_itransformer.pkl"), "rb"))
        pipeline.conformal_q = pickle.load(open(os.path.join(saved_files_dir, "conformal_q_itransformer.pkl"), "rb"))
    else:
        raise ValueError(f"Unsupported pipeline type: {pipeline_type}")
    data_frequency = pd.to_timedelta(config.get("data_frequency"))
    df = pd.read_parquet(config["parquet_path"])
    max_ts = df["ts"].max().floor(data_frequency)
    df = pivot_df(df)
    if "ts" not in df.columns and df.index.name == "ts":
        df = df.reset_index()
    elif "ts" not in df.columns:
        raise KeyError(f"Column 'ts' missing from data after pivoting. Available columns: {list(df.columns)}")

    # Forward fill trailing values (so the newest polled metrics extend to the latest timestamp)
    df = df.set_index("ts").interpolate("linear").bfill().ffill().reset_index()
    last_window = df.iloc[-window:]
    horizon = config.get("horizon")
    first_predicted = last_window.iloc[-1]["ts"] + pd.Timedelta(seconds=data_frequency.total_seconds())
    last_predicted = first_predicted + pd.Timedelta(seconds=data_frequency.total_seconds() * (horizon - 1))

    window_tensor = pipeline.preprocess_inference(
        last_window,
        targets,
        n_past=window,
        exclude_columns=cols_to_drop,
    )

    predictions = pipeline.infer(window_tensor)
    ingest_to_inference_parquet(predictions, first_predicted.timestamp(), last_predicted.timestamp(), data_frequency)

    output_dict = {}

    for (key, values), conformal_q in zip(predictions.items(), pipeline.conformal_q):
        metric_name, node_id = key.rsplit('_', 1)
        if node_id not in output_dict:
            output_dict[node_id] = {}
            
        output_dict[node_id][metric_name] = {
            "predicted_values": values,
            "conformal_q": conformal_q
        }

    output_dict["first_predicted"] = first_predicted
    output_dict["last_predicted"] = last_predicted
    output_dict["data_frequency"] = data_frequency

    return output_dict
